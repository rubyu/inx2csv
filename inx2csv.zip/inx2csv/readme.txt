

E-DIC英和和英第2版のinxファイルをcsvに変換するサンプル


[すべてのデータを出力する場合]

    usage: inx2csv.exe path_to_inx path_to_csv

この場合、出力は
----------
"02900000010","000","ABANDON TO , abandon somebody/something to somebody/something | ","「～を（あきらめて，見捨てて）～にゆだねる，任せる，引き渡す，明け渡す」¶The crew was forced to abandon their ship to the waves.（乗組員たちはついに船を捨て，船が波間に沈むに任せざるを得なかった）¶The cowardly captain abandoned his men to the enemy and fled.（意気地なしの隊長は，敵を前にして部下を見捨てて逃げ去った）"
"02900000010","001"," The crew was forced to abandon their ship to the waves.  | 乗組員たちはついに船を捨て，船が波間に沈むに任せざるを得なかった。 ",""
----------
のようになります。
カラムはそれぞれmain_id, sub_id, heading, bodyになり、sub_idが000以外の場合、bodyが空になります。
データは何も加工されず、そのまま出力されます。


[Ankiに適した出力]

    usage: inx2csv.exe --mode anki path_to_inx path_to_csv

この場合、出力は
----------
"ABANDON TO , abandon somebody/something to somebody/something","「～を（あきらめて，見捨てて）～にゆだねる，任せる，引き渡す，明け渡す」¶The crew was forced to abandon their ship to the waves.（乗組員たちはついに船を捨て，船が波間に沈むに任せざるを得なかった）¶The cowardly captain abandoned his men to the enemy and fled.（意気地なしの隊長は，敵を前にして部下を見捨てて逃げ去った）"
"ABANDON TO , abandon oneself to something","「（強い感情など）に身をゆだねる，ふける，くれる，～のとりこになる；（運命など）に身を任せる」¶For a week, we abandoned ourselves to the pleasures of New York.（１週間の間，私たちはニューヨークの楽しさのとりこになっていた）¶The young widow abandoned herself to her grief.（年若い寡婦は悲しみにくれていた）"
----------
のようになります。
データをそのまま出力はせず、作者のニーズに合わせて以下のような処理を行なっています。
ソースを同梱していますので適時改変してください。
・headingの最後の " | "を取り除いている。
・例文は出力しない。（sub_idが000のものだけ出力）
・▲▲～△△で囲まれている部分からIDを取り除いている。
・<CR>を<BR /><BR />に置換している。
・検索の利便性のための、リンクだけからなるアイテムについては取り除いている。


注意事項
・すべての辞書で動作確認はしていません。
・動作の結果生じる問題については責任は持てません。
